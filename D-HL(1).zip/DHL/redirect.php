<?php
 header('Location: //www.dhl.com/en.html')


  ?>